<script setup lang="ts">
</script>

<template>
  <RouterView />
</template>

<style>
main {
  width: 100%;
  box-sizing: border-box;
  padding: 1.5rem;
}

h5 {
  font-family: 'Amiri-Bold';
  font-size: 28px;
}
</style>