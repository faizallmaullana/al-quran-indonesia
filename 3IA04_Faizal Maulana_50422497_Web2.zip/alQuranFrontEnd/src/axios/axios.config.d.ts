declare module "@/axios/config" {
  import { AxiosInstance } from 'axios';
  
  const axios: AxiosInstance;
  export { axios };
}